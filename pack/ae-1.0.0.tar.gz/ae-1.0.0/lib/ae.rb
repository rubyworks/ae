module AE
  VERSION="1.0.0"  # :till: VERSION="<%= version %>"
end

require 'ae/assert'

# Copyright (c) 2008,2009 Thomas Sawyer
